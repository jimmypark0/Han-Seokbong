typedef struct {
	unsigned char *token;
	int length;
} TOKEN_STR;
